<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <style>
        .form-frame {
            padding: 2rem;
            margin: 1rem;
            border: solid black;
            border-width: .1rem;
            box-shadow: 2px 2px #9ca5c4;
        }
    </style>
</head>
<body>

<?php

include('inc/connection.php');

?>

<div class="container">

    <div class="form-frame">
        <table class="table">
            <thead>
            <tr>
                <th scope="col">product_id</th>
                <th scope="col">name</th>
                <th scope="col">price</th>
                <th scope="col">category</th>
                <th scope="col">sub_category</th>
                <th scope="col">picture</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $query = $db->query("select * from products");
            $products_array = $query->fetchAll(PDO::FETCH_ASSOC);

            foreach ($products_array as $product) { ?>
                <tr>
                    <th scope="row"><?php echo $product["product_id"] ?></th>
                    <td><?php echo $product["name"] ?></td>
                    <td><?php echo $product["price"] ?></td>
                    <td><?php echo $product["category"] ?></td>
                    <td><?php echo $product["sub_category"] ?></td>
                    <td><?php echo $product["picture"] ?></td>
                </tr>
                <?php
            }
            ?>
            </tbody>
        </table>
        <a class="btn btn-outline-dark m-2" href="add_product.php"> Add a new product</a>
        <a class="btn btn-outline-dark m-2" href="update_products.php"> Manage products</a>
    </div>

</div>
</body>
</html>
