<?php
session_start();
include('inc/connection.php');
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Main Page</title>
    <link rel="stylesheet" href="stylesheet.css">
    <script>
        function SearchFunction() {
            var input, filter, ul, li, a, i, txtValue;
            input = document.getElementById("myInput");
            filter = input.value.toUpperCase();
            ul = document.getElementById("myUL");
            li = ul.getElementsByTagName("li");
            for (i = 0; i < li.length; i++) {
                a = li[i].getElementsByTagName("a")[0];
                txtValue = a.textContent || a.innerText;
                if (filter.length === 0) {
                    li[i].style.display = "none";
                } else if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    li[i].style.display = "";
                } else {
                    li[i].style.display = "none";
                }
            }
        }
    </script>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW"
            crossorigin="anonymous"></script>
</head>
<body class="bg-dark" data-bs-spy="scroll" data-bs-target="#siteNav">
<div class="text-center p-2 bg-dark">
    <h1 class="display-1 mt-3 text-white">FASHION WEBSITE</h1>
    <p class="lead mb-5 text-light">
        Fashionable Products Brought To You By Designer X
    </p>
    <nav id="siteNav" class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">DX</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                    aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class=" text-dark nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink"
                           role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <?php
                            if (isset($_SESSION["email"])) { ?>
                                <b> <?php echo $_SESSION["email"] ?> </b>
                            <?php } else { ?>
                                <b> Account </b>
                            <?php } ?>
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <?php
                            if (isset($_SESSION["email"])) { ?>
                                <li><a class="dropdown-item" href="logout.php">Logout </a></li>
                            <?php } else { ?>
                                <li><a class="dropdown-item" href="login.php">Login</a></li>

                            <?php } ?>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class=" text-dark nav-link active" aria-current="page" href="#">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class=" text-dark nav-link" href="#About">About</a>
                    </li>
                    <?php
                    $query = $db->query("select  DISTINCT category from products");
                    $categories_array = $query->fetchAll(PDO::FETCH_ASSOC);
                    foreach ($categories_array as $category) { ?>
                        <li class="nav-item dropdown">
                            <a class=" text-dark nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink"
                               role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <?php
                                $cat = $category['category'];
                                echo $cat;
                                ?>
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                <li><a class="dropdown-item" href="categories.php#<?php echo $cat; ?>">
                                        All <?php echo $cat; ?></a></li>
                                <?php
                                $query = $db->prepare("select distinct sub_category from products where category = ?");
                                $query->bindValue(1, $cat);
                                $query->execute();
                                $subcategory_array = $query->fetchAll(PDO::FETCH_ASSOC);
                                foreach ($subcategory_array as $subcategory) { ?>
                                    <li><a class="dropdown-item"
                                           href="categories.php#<?php echo $subcategory['sub_category']; ?>"> <?php echo $subcategory['sub_category']; ?></a>
                                    </li>
                                <?php } ?>
                            </ul>
                        </li>
                    <?php } ?>
                </ul>
            </div>
        </div>
    </nav>
</div>
<section id="products">
    <h1 style=" background-color: mediumturquoise " class="display-3 text-center mx-2"><b> ALL PRODUCTS </b></h1>
    <div class="mx-2 row">
        <input type="text" id="myInput" onkeyup="SearchFunction();" placeholder="Search for product..">
        <ul id="myUL">
            <?php
            $query = $db->query("select * from products");
            $products_array = $query->fetchAll(PDO::FETCH_ASSOC);
            foreach ($products_array as $product) {
                ?>
                <li style="display: none;"><a href="product.php"><?php echo $product["name"]; ?></a></li>
                <?php
            }
            ?>
            <?php
            $query = $db->query("select  DISTINCT sub_category from products");
            $products_array = $query->fetchAll(PDO::FETCH_ASSOC);
            foreach ($products_array as $product) { ?>
                <li style="display: none;"><a href="categories.php#<?php echo $product['sub_category']; ?>">
                        <b> <?php echo $product['sub_category']; ?></b></a></li>
            <?php } ?>
        </ul>
        <?php
        $query = $db->query("select * from products");
        $products_array = $query->fetchAll(PDO::FETCH_ASSOC);
        foreach ($products_array as $product) {
            ?>
            <div class="col-md-6 col-lg-2">
                <div class="card mb-3">
                    <img src="img/<?php echo $product["picture"]; ?>" class="img-fluid" alt="Responsive image"
                         style="width: 400px; height: 400px;object-fit: cover;">
                    <div class="card-body">
                        <a style="text-decoration:none" href="product.php"><h4
                                    class="card-title text-dark"><?php echo $product["name"]; ?></h4></a>
                        <h5 class="card-text text-dark"><?php echo $product["price"]; ?></h5>
                        <p class="card-text text-dark"><a style="text-decoration:none"
                                                          href="categories.php#<?php echo $product["category"]; ?>"> <?php echo $product["category"]; ?> </a>
                            > <a style="text-decoration:none"
                                 href="categories.php#<?php echo $product["sub_category"]; ?>"> <?php echo $product["sub_category"]; ?> </a>
                        </p>
                    </div>
                </div>
            </div>
            <?php
        }
        ?>
    </div>
</section>
<section id="About">
    <div style=" background-color: ghostwhite" class="text-center mt-5 mx-2">
        <h1 style=" background-color: ghostwhite" class="display-4 text-center mx-2"><b> ABOUT </b></h1>
        <nav style=" background-color: ghostwhite" id="siteNav" class="navbar navbar-expand-lg navbar-light">
            <div class="container-fluid">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class=" text-dark nav-link active" aria-current="page" href="#">Home</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

    </div>
    <p class="text-light text-center mx-2"> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean non leo in
        mauris fringilla tristique. Vivamus ac pharetra leo. Integer in maximus sapien, et porta turpis. Sed nec libero
        sem. Mauris risus justo, lacinia at eros egestas, varius rutrum velit. Quisque mollis, enim eleifend rutrum
        dapibus, arcu tortor faucibus augue, eget faucibus dolor tortor nec sem. Quisque eleifend non nunc quis
        bibendum. Aenean efficitur purus sed magna ullamcorper imperdiet. Duis sed consequat libero. Etiam tristique
        lacus at nulla ullamcorper luctus.

        Sed euismod nunc non nunc laoreet porta. Pellentesque finibus mattis libero, sit amet congue augue sollicitudin
        a. Morbi blandit, est eget porttitor commodo, dui libero fermentum augue, aliquam gravida lacus mi eu felis. Nam
        vel egestas est. Fusce vitae ante dapibus, luctus elit eget, porta ligula. Duis ac rutrum nunc. Nunc eget metus
        lobortis ligula congue lobortis. Proin tempus rhoncus orci, nec ultrices orci gravida ut. Donec in sem at eros
        auctor venenatis sit amet non quam. Aliquam quam mauris, porttitor sit amet auctor nec, finibus id ex. Praesent
        vulputate pulvinar nibh. Nullam efficitur ipsum nec convallis tincidunt.

        Donec pulvinar justo sit amet ante egestas, eu auctor ipsum blandit. Integer eu ornare orci. Morbi pretium
        vulputate enim, sed rhoncus felis bibendum in. Phasellus non dui felis. Phasellus tempor enim vitae consectetur
        placerat. Maecenas nec lacus in eros maximus ornare sed a tellus. Sed lorem tellus, ornare et semper vel,
        tincidunt sit amet est. Proin sed neque nulla. Orci varius natoque penatibus et magnis dis parturient montes,
        nascetur ridiculus mus. Interdum et malesuada fames ac ante ipsum primis in faucibus. Phasellus auctor leo
        luctus nibh auctor, at ornare elit ultricies. Donec quis arcu at dui vehicula egestas. Mauris sed velit eget
        ipsum rutrum ornare. Nulla ut massa non erat sagittis lacinia. Fusce quis nisi egestas, aliquet nulla non,
        luctus eros.

        Vestibulum eget fermentum elit. Nunc tincidunt eros eu tortor aliquet laoreet. Nam luctus urna ut orci ornare,
        varius gravida felis congue. Fusce aliquet mi sem, ac blandit velit maximus eu. Suspendisse viverra ac eros ac
        auctor. Vestibulum at metus vel velit molestie egestas in id ante. Proin a quam sed nisi euismod rhoncus. Lorem
        ipsum dolor sit amet, consectetur adipiscing elit. Ut mattis ornare augue, ut fermentum odio elementum a. Sed
        vitae tortor tincidunt, rutrum dui non, maximus arcu. Nullam molestie tortor sit amet ullamcorper interdum.
        Maecenas fringilla, purus eget facilisis ultrices, elit felis sollicitudin nunc, vel suscipit massa mi at magna.
        Donec faucibus, ligula sed viverra fermentum, elit lectus tincidunt eros, vel maximus felis turpis eu neque. Sed
        felis eros, bibendum vel pellentesque et, fringilla nec leo. Vestibulum nec lacus finibus elit consectetur
        ultrices. Nulla quam massa, semper et tincidunt eu, ultricies ac augue.

        Nullam gravida, dui id luctus dictum, nisl purus vehicula felis, ac cursus felis ipsum in neque. In eu nisl ac
        augue lacinia ornare in id nulla. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac
        turpis egestas. Suspendisse dapibus tortor in felis iaculis, quis fermentum magna viverra. Praesent non risus ut
        tortor lacinia mattis mollis quis neque. Cras cursus elementum eros, eu pharetra risus aliquam sed. Vestibulum
        convallis, enim tincidunt bibendum commodo, libero risus dictum velit, ac ornare neque erat sed sapien.</p>
</section> <!-- About section -->
</body>
</html>