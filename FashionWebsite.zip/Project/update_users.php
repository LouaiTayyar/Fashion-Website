<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <style>
        .form-frame {
            padding: 2rem;
            margin: 1rem;
            border: solid black;
            border-width: .1rem;
            box-shadow: 2px 2px #9ca5c4;
        }
    </style>
</head>
<body>
<?php
session_start();
$user_id = $_POST["user_id"];
$action = $_POST["action"];
$email = $_POST["email"];
$password = $_POST["password"];

include('inc/connection.php');

if ($action == "delete") {
    $query = $db->prepare("delete from users where user_id = ?");
    $query->bindValue(1, $user_id);
    $query->execute();
}
if ($action == "update") {
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $update_statement = $db->prepare("UPDATE users SET email = ?, password = ? WHERE user_id = ?");
    $update_statement->bindValue(1, $email);
    $update_statement->bindValue(2, $hashed_password);
    $update_statement->bindValue(3, $user_id);
    $update_statement->execute();
}

?>

<div class="container">
    <h1 class="text-center"> User List</h1>
    <div class="form-frame">
        <table class="table">
            <thead>
            <tr>
                <th scope="col">user_id</th>
                <th scope="col">email</th>
                <th scope="col">password</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $query = $db->query("select * from users");
            $users_array = $query->fetchAll(PDO::FETCH_ASSOC);

            foreach ($users_array as $user) { ?>
                <tr>
                    <th scope="row"><?php echo $user["user_id"] ?></th>
                    <td><?php echo $user["email"] ?></td>
                    <td><?php echo $user["password"] ?></td>
                </tr>
                <?php
            }
            ?>
            </tbody>
        </table>
        <a class="btn btn-outline-dark m-2" href="register_user.php"> Register New User</a>
    </div>
</div>

<div class="container">
    <h2 class="text-center"> Manage Users </h2>
    <div class="form-frame">
        <form method="post" action="update_users.php">
            <label class="form-group m-2" for="user_id">Choose user ID:</label>
            <select id="user_id" name="user_id">
                <?php
                $query = $db->query("select user_id from users");
                $users_array = $query->fetchAll(PDO::FETCH_ASSOC);
                foreach ($users_array as $user) {
                    ?>
                    <option value="<?php echo $user["user_id"] ?>"> <?php echo $user["user_id"] ?></option>
                    <?php
                }
                ?>
            </select>
            <select id="action" name="action">
                <option value="delete">Delete</option>
                <option value="update">Update</option>
            </select>
            <br><br>
            <div class="form-group m-2">
                <label for="email">User email</label>
                <input class="form-control" type="text" id="email" name="email" placeholder="Enter new email..">
            </div>
            <div class="form-group m-2">
                <label for="password">Password</label>
                <input class="form-control" type="text" id="password" name="password"/>
            </div>
            <button type="submit" class="btn btn-outline-dark m-2">Submit</button>
        </form>
    </div>
</div>
</body>
</html>