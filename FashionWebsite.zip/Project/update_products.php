<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <style>
        .form-frame {
            padding: 2rem;
            margin: 1rem;
            border: solid black;
            border-width: .1rem;
            box-shadow: 2px 2px #9ca5c4;
        }
    </style>
</head>
<body>
<?php
session_start();
$product_id = $_POST["product_id"];
$action = $_POST["action"];
$name = $_POST["name"];
$price = $_POST["price"];
$category = $_POST["category"];
$sub_category = $_POST["sub_category"];
$picture = $_POST["picture"];


include('inc/connection.php');

if ($action == "delete") {
    $query = $db->prepare("delete from products where product_id = ?");
    $query->bindValue(1, $product_id);
    $query->execute();
}

if ($action == "update") {

    $update_statement = $db->prepare("UPDATE products SET name = ?, price = ?,category = ?,sub_category = ?,picture = ? WHERE product_id = ?");
    $update_statement->bindValue(1, $name);
    $update_statement->bindValue(2, $price);
    $update_statement->bindValue(3, $category);
    $update_statement->bindValue(4, $sub_category);
    $update_statement->bindValue(5, $picture);
    $update_statement->bindValue(6, $product_id);
    $update_statement->execute();
}
?>
<section id="product_list">
    <div class="container">
        <h1 class="text-center"> Product List</h1>
        <?php
        session_start();
        //if (isset($_SESSION["email"])) {
        //  echo 'You are: ' . $_SESSION["email"] . '<br>';
        //}
        ?>
        <div class="form-frame">
            <table class="table">
                <thead>
                <tr>
                    <th scope="col">product_id</th>
                    <th scope="col">name</th>
                    <th scope="col">price</th>
                    <th scope="col">category</th>
                    <th scope="col">sub_category</th>
                    <th scope="col">picture</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $query = $db->query("select * from products");
                $products_array = $query->fetchAll(PDO::FETCH_ASSOC);

                foreach ($products_array as $product) { ?>
                    <tr>
                        <th scope="row"><?php echo $product["product_id"] ?></th>
                        <td><?php echo $product["name"] ?></td>
                        <td><?php echo $product["price"] ?></td>
                        <td><?php echo $product["category"] ?></td>
                        <td><?php echo $product["sub_category"] ?></td>
                        <td><?php echo $product["picture"] ?></td>
                    </tr>
                    <?php
                }
                ?>
                </tbody>
            </table>
            <a class="btn btn-outline-dark m-2" href="add_product.php"> Add a new product</a>
        </div>
    </div>
</section>

<section id="manage_products">
    <div class="container">
        <h2 class="text-center"> Manage Products </h2>
        <div class="form-frame">
            <form method="post" action="update_products.php">
                <label class="form-group m-2" for="product_id">Choose product ID:</label>
                <select id="product_id" name="product_id">
                    <?php

                    $query = $db->query("select product_id from products");
                    $products_array = $query->fetchAll(PDO::FETCH_ASSOC);

                    foreach ($products_array as $product) {
                        ?>
                        <option
                        value="<?php echo $product["product_id"] ?>"> <?php echo $product["product_id"] ?></option>
                        <?php
                    }

                    ?>
                </select>
                <select id="action" name="action">
                    <option value="delete">Delete</option>
                    <option value="update">Update</option>
                </select>
                <br><br>
                <div class="form-group m-2">
                    <label for="name">Product Name</label>
                    <input class="form-control" type="text" id="name" name="name" placeholder="Enter product name..">
                </div>
                <div class="form-group m-2">
                    <label for="price">Product Price</label>
                    <input class="form-control" type="text" id="price" name="price"/>
                </div>

                <div class="form-group m-2">
                    <label for="category">Product Category</label>
                    <br>
                    <input name="category" type="text" list="category"/>
                    <datalist id="category" name="category">
                        <?php
                        $query = $db->query("select  DISTINCT category from products");
                        $products_array = $query->fetchAll(PDO::FETCH_ASSOC);
                        foreach ($products_array as $product) { ?>
                            <option value="<?php echo $product['category']; ?>">
                                <?php echo $product['category']; ?>       </option>
                        <?php } ?>
                    </datalist>
                </div>
                <div class="form-group m-2">
                    <label for="sub_category">Product Sub-category</label>
                    <br>
                    <input name="sub_category" type="text" list="sub_category"/>
                    <datalist id="sub_category" name="sub_category">
                        <?php
                        $query = $db->query("select  DISTINCT sub_category from products");
                        $products_array = $query->fetchAll(PDO::FETCH_ASSOC);
                        foreach ($products_array as $product) { ?>
                            <option value="<?php echo $product['sub_category']; ?>">
                                <?php echo $product['sub_category']; ?>       </option>
                        <?php } ?>
                    </datalist>
                </div>
                <div class="form-group m-2">
                    <label for="picture">Product Picture URL</label>
                    <input class="form-control" type="text" id="picture" name="picture"/>
                </div>
                <button type="submit" class="btn btn-outline-dark m-2">Submit</button>
            </form>
        </div>
    </div>
</section>
</body>
</html>
