<?php
session_start();
ini_set('display_errors', 1);
ini_set('error_log', 'php_errors.log');

$email = $_POST['email'];
$password = $_POST['password'];
include('inc/connection.php');

$query = $db->prepare("select * from users where email = ?");
$query->bindValue(1, $email);
$query->execute();
$userdetails = $query->fetchAll(PDO::FETCH_ASSOC);

$rows = $query->rowCount();
if ($email == "admin@admin" && $password == "admin") {
    $_SESSION['email'] = "admin";
    $_SESSION['isAdmin'] = "true";
    header("Location: admin_page.php");
} else if ($rows == 1 && password_verify($password, $userdetails[0]["password"])) {
    $_SESSION['email'] = $email;
    $_SESSION['isAdmin'] = "false";
    header("Location: main.php");
} else {
    echo 'Wrong username or password';
}


