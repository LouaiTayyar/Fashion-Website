<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <style>
        .form-frame {
            padding: 2rem;
            margin: 1rem;
            border: solid black;
            border-width: .1rem;
            box-shadow: 2px 2px #9ca5c4;
        }
    </style>
</head>
<body>
<?php

include('inc/connection.php');

?>

<div class="container">
    <h1 class="text-center"> User List</h1>
    <div class="form-frame">
        <table class="table">
            <thead>
            <tr>
                <th scope="col">user_id</th>
                <th scope="col">email</th>
                <th scope="col">password</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $query = $db->query("select * from users");
            $users_array = $query->fetchAll(PDO::FETCH_ASSOC);

            foreach ($users_array as $user) { ?>
                <tr>
                    <th scope="row"><?php echo $user["user_id"] ?></th>
                    <td><?php echo $user["email"] ?></td>
                    <td><?php echo $user["password"] ?></td>
                </tr>
                <?php
            }
            ?>
            </tbody>
        </table>
        <a class="btn btn-outline-dark m-2" href="register_user.php"> Register New User</a>
        <a class="btn btn-outline-dark m-2" href="update_users.php"> Manage Users</a>
    </div>
</div>
</body>
</html>
