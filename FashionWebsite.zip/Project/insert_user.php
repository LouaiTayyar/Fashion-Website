<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <style>
        .form-frame {
            padding: 2rem;
            margin: 1rem;
            border: solid black;
            border-width: .1rem;
            box-shadow: 2px 2px #9ca5c4;
        }
    </style>
</head>
<body>
<?php

$email = $_POST['email'];
$password = $_POST['password'];
include('inc/connection.php');

$hashed_password = password_hash($password, PASSWORD_DEFAULT);

$query = $db->prepare("insert into users(email, password) values (? , ?) ");
$query->bindValue(1, $email);
$query->bindValue(2, $hashed_password);
$query->execute();
?>
<div class="container">
    <div class="form-frame">
        <h5> New User is now registered !</h5>
        <br>
        <a class="btn btn-outline-dark m-2" href="main.php"> Go to main page</a>
    </div>
</div>

</body>
</html>
