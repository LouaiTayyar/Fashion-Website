<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.6.0/dist/umd/popper.min.js"
            integrity="sha384-KsvD1yqQ1/1+IA7gi3P0tyJcT3vR+NdBTt13hSJ2lnve8agRGXTTyNaBYmCR/Nwi"
            crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.min.js"
            integrity="sha384-nsg8ua9HAw1y0W1btsyWgBklPnCUAFLuTMS2G72MMONqmOymq585AcH49TLBQObG"
            crossorigin="anonymous"></script>
    <style>
        .form-frame {
            padding: 2rem;
            margin: 1rem;
            border: solid black;
            border-width: .1rem;
            box-shadow: 2px 2px #9ca5c4;
        }
    </style>
</head>
<body>

<?php
include('inc/connection.php');
$query = $db->query("select * from products");
$projects_array = $query->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="container">
    <h1 class="my-2 text-center"> ADD A NEW PRODUCT </h1>
    <div class="form-frame">
        <form method="POST" action="insert_product.php">
            <div class="form-group m-2">
                <label for="name">Product Name</label>
                <input class="form-control" type="text" id="name" name="name" required
                       placeholder="Enter product name..">
            </div>
            <div class="form-group m-2">
                <label for="price">Product Price</label>
                <input class="form-control" type="text" id="price" name="price" required/>
            </div>
            <div class="form-group m-2">
                <label for="category">Product Category</label>
                <input class="form-control" name="category" type="text" list="category"/>
                <datalist id="category" name="category">
                    <?php
                    $query = $db->query("select  DISTINCT category from products");
                    $products_array = $query->fetchAll(PDO::FETCH_ASSOC);
                    foreach ($products_array as $product) { ?>
                        <option value="<?php echo $product['category']; ?>">
                            <?php echo $product['category']; ?>       </option>
                    <?php } ?>
                </datalist>
            </div>
            <div class="form-group m-2">
                <label for="sub_category">Product Sub-category</label>
                <input class="form-control" name="sub_category" type="text" list="sub_category"/>
                <datalist id="sub_category" name="sub_category">
                    <?php
                    $query = $db->query("select  DISTINCT sub_category from products");
                    $products_array = $query->fetchAll(PDO::FETCH_ASSOC);
                    foreach ($products_array as $product) { ?>
                        <option value="<?php echo $product['sub_category']; ?>">
                            <?php echo $product['sub_category']; ?>       </option>
                    <?php } ?>
                </datalist>
            </div>
            <div class="form-group m-2">
                <label for="picture">Product Picture URL</label>
                <input class="form-control" type="text" id="picture" name="picture" required/>
            </div>
            <button type="submit" class="btn btn-outline-dark m-2">Submit</button>
            <a class="btn btn-outline-dark m-2" href="product_list.php"> View Products </a>
        </form>
    </div>
</div>
</body>
</html>