<?php
include('inc/connection.php');
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Categories</title>
    <link rel="stylesheet" href="stylesheet.css">
    <script>
        function SearchFunction() {
            var input, filter, ul, li, a, i, txtValue;
            input = document.getElementById("myInput");
            filter = input.value.toUpperCase();
            ul = document.getElementById("myUL");
            li = ul.getElementsByTagName("li");
            for (i = 0; i < li.length; i++) {
                a = li[i].getElementsByTagName("a")[0];
                txtValue = a.textContent || a.innerText;
                if (filter.length === 0) {
                    li[i].style.display = "none";
                } else if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    li[i].style.display = "";
                } else {
                    li[i].style.display = "none";
                }
            }
        }
    </script>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW"
            crossorigin="anonymous"></script>
</head>
<body class="bg-dark" data-bs-spy="scroll" data-bs-target="#siteNav">
<div class="text-center p-2 bg-dark">
    <h1 class="display-1 mt-3 text-white">FASHION WEBSITE</h1>
    <p class="lead mb-5 text-light">
        Fashionable Products Brought To You By Designer X
    </p>
    <?php
    $query = $db->query("select  DISTINCT category from products");
    $categories_array = $query->fetchAll(PDO::FETCH_ASSOC);
    foreach ($categories_array as $category) { ?>
        <section id="<?php echo $category['category']; ?>">
            <div style=" background-color: mediumturquoise" class="text-center p-2 ">
                <h1 style=" background-color: mediumturquoise" class="display-4 text-center">
                    <b><?php echo $category['category']; ?></b></h1>
                <nav style=" background-color: mediumturquoise" id="siteNav"
                     class="navbar navbar-expand-lg navbar-light">
                    <div class="container-fluid">
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                                data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false"
                                aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarNav">
                            <ul class="navbar-nav">
                                <li class="nav-item">
                                    <a class=" text-dark nav-link active" aria-current="page" href="main.php#">Home</a>
                                </li>
                                <?php
                                $cat = $category['category'];
                                $query = $db->prepare("select distinct sub_category from products where category = ?");
                                $query->bindValue(1, $cat);
                                $query->execute();
                                $subcategory_array = $query->fetchAll(PDO::FETCH_ASSOC);
                                foreach ($subcategory_array as $subcategory) { ?>
                                    <li class="nav-item">
                                        <a class="nav-link"
                                           href="#<?php echo $subcategory['sub_category']; ?>"><?php echo $subcategory['sub_category']; ?></a>
                                    </li>
                                <?php } ?>
                            </ul>
                        </div>
                    </div>
                </nav>
            </div>
            <input type="text" id="myInput" onkeyup="SearchFunction();" placeholder="Search for product..">
            <ul id="myUL">
                <?php
                $query = $db->query("select * from products");
                $products_array = $query->fetchAll(PDO::FETCH_ASSOC);
                foreach ($products_array as $product) {
                    ?>
                    <li style="display: none;"><a href="product.php"><?php echo $product["name"]; ?></a></li>
                    <?php
                }
                ?>
                <?php
                $query = $db->query("select  DISTINCT sub_category from products");
                $products_array = $query->fetchAll(PDO::FETCH_ASSOC);
                foreach ($products_array as $product) { ?>
                    <li style="display: none;"><a href="categories.php#<?php echo $product['sub_category']; ?>">
                            <b> <?php echo $product['sub_category']; ?></b></a></li>
                <?php } ?>
            </ul>
            <?php
            $cat = $category['category'];
            $query = $db->prepare("select distinct sub_category from products where category = ?");
            $query->bindValue(1, $cat);
            $query->execute();
            $subcategory_array = $query->fetchAll(PDO::FETCH_ASSOC);
            foreach ($subcategory_array as $subcategory) { ?>
                <section id="<?php echo $subcategory['sub_category']; ?>">
                    <h1 style=" background-color: whitesmoke"
                        class="display-5 text-center my-3"> <?php echo $subcategory['sub_category']; ?> </h1>
                    <div class="row">
                        <?php
                        $sub = $subcategory['sub_category'];
                        $query = $db->prepare("select * from products where sub_category = ?");
                        $query->bindValue(1, $sub);
                        $query->execute();
                        $products_array = $query->fetchAll(PDO::FETCH_ASSOC);
                        foreach ($products_array as $product) { ?>
                            <div class="col-md-6 col-lg-2">
                                <div class="card mb-3">
                                    <img src="img/<?php echo $product["picture"]; ?>" class="img-fluid"
                                         alt="Responsive image" style="width: 400px; height: 400px;object-fit: cover;">
                                    <div class="card-body">
                                        <a style="text-decoration:none" href="product.php"><h4
                                                    class="card-title text-dark"><?php echo $product["name"]; ?></h4>
                                        </a>
                                        <h5 class="card-text text-dark"><?php echo $product["price"]; ?></h5>
                                        <p class="card-text text-dark"><a style="text-decoration:none"
                                                                          href="#<?php echo $product["category"]; ?>"> <?php echo $product["category"]; ?> </a>
                                            > <a style="text-decoration:none"
                                                 href="#<?php echo $product["sub_category"]; ?>"> <?php echo $product["sub_category"]; ?> </a>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                </section>
            <?php } ?>
        </section>
    <?php } ?>
</body>
</html>