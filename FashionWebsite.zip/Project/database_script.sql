create table products (
                          product_id int(11) NOT NULL,
                          name text NOT NULL,
                          price text NOT NULL,
                          category text NOT NULL,
                          sub_category text NOT NULL,
                          picture text
);

alter table products add primary key (product_id);

insert into products values (1, 'Red Dress', '$60','Clothing','Dresses','reddress.png');
insert into products values (2, 'White Shirt', '$20','Clothing','Shirts','whiteshirt2.png');
insert into products values (3, 'Blue Jeans', '$30','Clothing','Pants','bluejeans.png');
insert into products values (4, 'White Dress', '$90','Clothing','Dresses','whitedress.png');
insert into products values (5, 'Black Shirt', '$25','Clothing','Shirts','blackshirt.png');
insert into products values (6, 'Black Jeans', '$40','Clothing','Pants','blackjeans.png');
insert into products values (7, 'Silver Ring', '$15','Accesories','Rings','silverring.png');
insert into products values (8, 'Pearl Necklace', '$55','Accesories','Necklaces','pearlnecklace.png');
insert into products values (9, 'Yellow Earings', '$25','Accesories','Earings','yellowearings.png');



alter table products modify product_id int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;


create table users (
                       user_id int(11) PRIMARY KEY AUTO_INCREMENT,
                       email varchar(50) not null UNIQUE,
                       password varchar(300) not null
);

