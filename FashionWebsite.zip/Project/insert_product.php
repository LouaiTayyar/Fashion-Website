<?php
$name = $_POST["name"];
$price = $_POST["price"];
$category = $_POST["category"];
$sub_category = $_POST["sub_category"];
$picture = $_POST["picture"];

include('inc/connection.php');
try {
    $insert_statement = $db->prepare("insert into products (name, price, category,sub_category,picture) values ( ? , ? , ?, ?, ?)");
    $insert_statement->bindValue(1, $name);
    $insert_statement->bindValue(2, $price);
    $insert_statement->bindValue(3, $category);
    $insert_statement->bindValue(4, $sub_category);
    $insert_statement->bindValue(5, $picture);
    $insert_statement->execute();
    header("Location: product_list.php");
} catch (Exception $e) {
    echo 'Insert error' . $e->getMessage() . "</br>";
}
?>
