<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <style>
        .form-frame {
            padding: 2rem;
            margin: 1rem;
            border: solid goldenrod;
            border-width: .1rem;
            box-shadow: 2px 2px #9ca5c4;
        }
    </style>
</head>
<body>
<?php
session_start();
//var_dump($_SESSION);
if (isset($_SESSION["email"])) {
    header("Location: main.php");
} else {
    ?>
    <div class="col-lg-2 container">
        <h1 style="text-align: center">Login</h1>
        <div class="form-frame">
            <form method="POST" action="login_account.php">
                <input type="email" id="email" name="email" required placeholder="email"> </br>
                <input type="password" id="password" name="password" placeholder="password" required> </br>
                <input type="submit" value="Login">
            </form>
        </div>
    </div>
<?php } ?>
</body>
</html>